/**
 * Split PDF Tool Components
 * Requirements: 5.1, 5.2
 */

export { SplitPDFTool, type SplitPDFToolProps } from './SplitPDFTool';
