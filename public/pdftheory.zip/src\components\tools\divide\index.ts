/**
 * Divide Pages Tool Component
 * Requirements: 5.1
 */

export { DividePagesTool } from './DividePagesTool';
export { default } from './DividePagesTool';
