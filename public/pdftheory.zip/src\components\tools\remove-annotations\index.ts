export { RemoveAnnotationsTool, type RemoveAnnotationsToolProps } from './RemoveAnnotationsTool';
