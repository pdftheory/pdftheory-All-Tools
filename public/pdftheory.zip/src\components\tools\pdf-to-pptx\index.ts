export { PDFToPptxTool, type PDFToPptxToolProps } from './PDFToPptxTool';
