export { ChangePermissionsTool, type ChangePermissionsToolProps } from './ChangePermissionsTool';
export { default } from './ChangePermissionsTool';
