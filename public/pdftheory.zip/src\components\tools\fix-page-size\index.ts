export { FixPageSizeTool, type FixPageSizeToolProps } from './FixPageSizeTool';
export { default } from './FixPageSizeTool';
