/**
 * PDF Multi Tool Component
 * Requirements: 5.1
 * 
 * All-in-one PDF editor combining multiple operations.
 */

export { PDFMultiTool, type PDFMultiToolProps } from './PDFMultiTool';
