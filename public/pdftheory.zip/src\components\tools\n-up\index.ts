/**
 * N-Up PDF Tool exports
 * Requirements: 5.1
 */

export { NUpPDFTool } from './NUpPDFTool';
export type { NUpPDFToolProps } from './NUpPDFTool';
