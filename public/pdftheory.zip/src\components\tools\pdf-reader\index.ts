export { PDFReaderTool, type PDFReaderToolProps } from './PDFReaderTool';
export { default } from './PDFReaderTool';
