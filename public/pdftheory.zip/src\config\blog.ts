export interface BlogPost {
    id: string;
    slug: string;
    title: string;
    excerpt: string;
    content: string;
    category: BlogCategory;
    featuredImage: string;
    author: string;
    publishedAt: string;
    readingTime: number;
    tags: string[];
}

export type BlogCategory = 'tutorials' | 'productivity' | 'news' | 'tips';

export const BLOG_CATEGORIES: Record<BlogCategory, { label: string; color: string }> = {
    tutorials: { label: 'Tutorials', color: 'bg-blue-500' },
    productivity: { label: 'Productivity', color: 'bg-green-500' },
    news: { label: 'News', color: 'bg-purple-500' },
    tips: { label: 'Tips & Tricks', color: 'bg-orange-500' },
};

export const blogPosts: BlogPost[] = [
    {
        id: '1',
        slug: 'how-to-merge-pdf-files',
        title: 'How to Merge PDF Files: A Complete Guide',
        excerpt: 'Learn the easiest ways to combine multiple PDF documents into a single file. This comprehensive guide covers online tools, desktop software, and mobile apps.',
        content: `
# How to Merge PDF Files: A Complete Guide

Merging PDF files is one of the most common tasks when working with documents. Whether you're combining reports, contracts, or presentations, having the right tools makes all the difference.

## Why Merge PDFs?

There are many reasons you might need to merge PDF files:
- Combining multiple invoices into one document
- Creating a single portfolio from separate files
- Organizing scattered documents into one cohesive file
- Preparing documents for printing or sharing

## Using Our Online Tool

1. **Upload your files** - Drag and drop your PDFs or click to browse
2. **Arrange the order** - Drag files to reorder them
3. **Click Merge** - Download your combined PDF instantly

## Tips for Best Results

- Ensure all PDFs are not password-protected
- Check file sizes before merging large documents
- Preview the final result before downloading
    `,
        category: 'tutorials',
        featuredImage: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=800&h=450&fit=crop',
        author: 'PDFTheory Team',
        publishedAt: '2026-01-28',
        readingTime: 5,
        tags: ['merge', 'pdf', 'tutorial', 'beginner'],
    },

    {
        id: '3',
        slug: '10-productivity-tips-for-pdf-workflows',
        title: '10 Productivity Tips for PDF Workflows',
        excerpt: 'Boost your productivity with these essential tips for managing PDF documents efficiently in your daily workflow.',
        content: `
# 10 Productivity Tips for PDF Workflows

Working with PDFs doesn't have to be time-consuming. Here are 10 tips to supercharge your document workflow.

## 1. Use Keyboard Shortcuts
Learn the essential shortcuts for your PDF tools to save time.

## 2. Batch Process Files
Process multiple files at once instead of one by one.

## 3. Create Templates
Save commonly used layouts as templates for quick reuse.

## 4. Use OCR for Scanned Documents
Convert scanned documents to searchable text.

## 5. Organize with Bookmarks
Add bookmarks to long documents for easy navigation.

## 6. Annotate Instead of Printing
Use digital annotations to save paper and time.

## 7. Set Up Cloud Sync
Keep your documents accessible from any device.

## 8. Use Form Fields
Create fillable forms instead of static documents.

## 9. Compress Before Sending
Always compress PDFs before emailing.

## 10. Back Up Regularly
Use cloud storage for automatic backups.
    `,
        category: 'productivity',
        featuredImage: 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=800&h=450&fit=crop',
        author: 'PDFTheory Team',
        publishedAt: '2026-01-22',
        readingTime: 7,
        tags: ['productivity', 'tips', 'workflow', 'efficiency'],
    },
    {
        id: '4',
        slug: 'pdf-security-best-practices',
        title: 'PDF Security: Best Practices for Protecting Your Documents',
        excerpt: 'Keep your sensitive documents safe with these essential security practices for PDF files.',
        content: `
# PDF Security: Best Practices for Protecting Your Documents

In an age of digital document sharing, security is paramount. Learn how to protect your PDFs from unauthorized access.

## Password Protection

Add strong passwords to prevent unauthorized opening:
- Use a mix of letters, numbers, and symbols
- Avoid common words and patterns
- Change passwords regularly

## Permission Restrictions

Control what others can do with your PDF:
- Prevent printing
- Disable copying text
- Restrict editing

## Digital Signatures

Verify document authenticity with digital signatures:
- Proves the document hasn't been altered
- Confirms the identity of the signer
- Legally binding in many jurisdictions

## Encryption Standards

Use industry-standard encryption:
- AES 256-bit encryption for maximum security
- Compatible with all major PDF readers
    `,
        category: 'tips',
        featuredImage: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=800&h=450&fit=crop',
        author: 'PDFTheory Team',
        publishedAt: '2026-01-20',
        readingTime: 6,
        tags: ['security', 'encryption', 'password', 'protection'],
    },
    {
        id: '5',
        slug: 'new-features-january-2026',
        title: 'New Features Released in January 2026',
        excerpt: 'Check out the latest features and improvements we\'ve added to make your PDF experience even better.',
        content: `
# New Features Released in January 2026

We're excited to announce several new features and improvements to PDFTheory!

## What's New

### Enhanced PDF Editor
- New annotation tools
- Improved text editing
- Better shape and drawing options

### Faster Processing
- 50% faster file uploads
- Improved compression algorithms
- Quicker conversion times

### Mobile Improvements
- Redesigned mobile interface
- Better touch controls
- Offline mode support

### Security Updates
- Enhanced encryption options
- New password policies
- Improved access controls

## Coming Soon

Stay tuned for more exciting features in the coming months!
    `,
        category: 'news',
        featuredImage: 'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?w=800&h=450&fit=crop',
        author: 'PDFTheory Team',
        publishedAt: '2026-01-15',
        readingTime: 3,
        tags: ['news', 'updates', 'features', 'announcement'],
    },
    {
        id: '6',
        slug: 'convert-pdf-to-word-guide',
        title: 'How to Convert PDF to Word: Preserve Your Formatting',
        excerpt: 'Convert PDF documents to editable Word files while keeping your original formatting intact.',
        content: `
# How to Convert PDF to Word: Preserve Your Formatting

Need to edit a PDF document? Converting to Word is often the best solution. Here's how to do it right.

## Why Convert PDF to Word?

- Edit text and images easily
- Reformat document layout
- Extract specific content
- Collaborate with others

## Best Practices

1. Use high-quality source PDFs
2. Check for scanned vs. native PDFs
3. Review the converted document
4. Make necessary adjustments

## Common Issues and Solutions

### Formatting Problems
Some complex layouts may not convert perfectly. Manual adjustments may be needed.

### Missing Fonts
If fonts aren't available, the converter will substitute similar ones.

### Image Quality
Embedded images maintain their original quality during conversion.
    `,
        category: 'tutorials',
        featuredImage: 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=800&h=450&fit=crop',
        author: 'PDFTheory Team',
        publishedAt: '2026-01-10',
        readingTime: 5,
        tags: ['convert', 'word', 'docx', 'tutorial'],
    },
];

export function getBlogPostBySlug(slug: string): BlogPost | undefined {
    return blogPosts.find((post) => post.slug === slug);
}

export function getBlogPostsByCategory(category: BlogCategory): BlogPost[] {
    return blogPosts.filter((post) => post.category === category);
}

export function searchBlogPosts(query: string): BlogPost[] {
    const lowerQuery = query.toLowerCase();
    return blogPosts.filter(
        (post) =>
            post.title.toLowerCase().includes(lowerQuery) ||
            post.excerpt.toLowerCase().includes(lowerQuery) ||
            post.tags.some((tag) => tag.toLowerCase().includes(lowerQuery))
    );
}

export function getRecentBlogPosts(limit: number = 3): BlogPost[] {
    return [...blogPosts]
        .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime())
        .slice(0, limit);
}
