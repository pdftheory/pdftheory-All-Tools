export { PDFToGreyscaleTool, type PDFToGreyscaleToolProps } from './PDFToGreyscaleTool';
export { default } from './PDFToGreyscaleTool';
