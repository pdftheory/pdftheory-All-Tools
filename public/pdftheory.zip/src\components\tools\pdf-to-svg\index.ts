export { PDFToSVGTool, type PDFToSVGToolProps } from './PDFToSVGTool';
export { PDFToSVGTool as default } from './PDFToSVGTool';
