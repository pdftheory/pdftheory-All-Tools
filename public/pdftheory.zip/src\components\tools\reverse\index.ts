/**
 * Reverse Pages Tool exports
 * Requirements: 5.1
 */

export { ReversePagesTool } from './ReversePagesTool';
export type { ReversePagesToolProps } from './ReversePagesTool';
