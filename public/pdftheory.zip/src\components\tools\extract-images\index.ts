export { ExtractImagesTool, type ExtractImagesToolProps } from './ExtractImagesTool';
export { default } from './ExtractImagesTool';
