export { DecryptPDFTool, type DecryptPDFToolProps } from './DecryptPDFTool';
export { default } from './DecryptPDFTool';
