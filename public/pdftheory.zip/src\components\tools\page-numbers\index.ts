export { PageNumbersTool, type PageNumbersToolProps } from './PageNumbersTool';
