export { CombineSinglePageTool, type CombineSinglePageToolProps } from './CombineSinglePageTool';
export { default } from './CombineSinglePageTool';
