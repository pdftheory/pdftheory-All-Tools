export { FlattenPDFTool, type FlattenPDFToolProps } from './FlattenPDFTool';
export { default } from './FlattenPDFTool';
