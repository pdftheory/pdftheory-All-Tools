export { ExtractTablesTool, type ExtractTablesToolProps } from './ExtractTablesTool';
export { default } from './ExtractTablesTool';
