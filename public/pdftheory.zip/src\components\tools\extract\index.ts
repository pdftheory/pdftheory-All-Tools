export { ExtractPagesTool, type ExtractPagesToolProps } from './ExtractPagesTool';
export { default } from './ExtractPagesTool';
