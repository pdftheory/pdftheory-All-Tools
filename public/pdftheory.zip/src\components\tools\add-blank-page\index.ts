/**
 * Add Blank Page Tool exports
 * Requirements: 5.1
 */

export { AddBlankPageTool } from './AddBlankPageTool';
export type { AddBlankPageToolProps } from './AddBlankPageTool';
