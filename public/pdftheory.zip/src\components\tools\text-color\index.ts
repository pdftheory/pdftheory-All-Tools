export { TextColorTool, type TextColorToolProps } from './TextColorTool';
