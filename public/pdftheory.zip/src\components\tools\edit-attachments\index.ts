export { EditAttachmentsTool, type EditAttachmentsToolProps } from './EditAttachmentsTool';
export { default } from './EditAttachmentsTool';
