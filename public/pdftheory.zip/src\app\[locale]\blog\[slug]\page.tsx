import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { setRequestLocale, getTranslations } from 'next-intl/server';
import { locales, type Locale } from '@/lib/i18n/config';
import { blogPosts, getBlogPostBySlug } from '@/config/blog';
import BlogPostClient from './BlogPostClient';

export function generateStaticParams() {
    return locales.flatMap((locale) =>
        blogPosts.map((post) => ({
            locale,
            slug: post.slug,
        }))
    );
}

export async function generateMetadata({
    params,
}: {
    params: Promise<{ locale: string; slug: string }>;
}): Promise<Metadata> {
    const { locale, slug } = await params;
    const post = getBlogPostBySlug(slug);

    if (!post) {
        return {
            title: 'Post Not Found',
        };
    }

    return {
        title: post.title,
        description: post.excerpt,
        openGraph: {
            title: post.title,
            description: post.excerpt,
            type: 'article',
            publishedTime: post.publishedAt,
            authors: [post.author],
            images: [post.featuredImage],
        },
    };
}

interface BlogPostPageProps {
    params: Promise<{ locale: string; slug: string }>;
}

export default async function BlogPostPage({ params }: BlogPostPageProps) {
    const { locale, slug } = await params;
    const validLocale = locales.includes(locale as Locale) ? (locale as Locale) : 'en';
    const post = getBlogPostBySlug(slug);

    if (!post) {
        notFound();
    }

    // Enable static rendering
    setRequestLocale(validLocale);

    return <BlogPostClient post={post} locale={validLocale} />;
}
