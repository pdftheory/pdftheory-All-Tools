export { PDFsToZipTool, type PDFsToZipToolProps } from './PDFsToZipTool';
export { default } from './PDFsToZipTool';
