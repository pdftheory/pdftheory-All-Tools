export { ViewMetadataTool, type ViewMetadataToolProps, type PDFMetadata } from './ViewMetadataTool';
export { default } from './ViewMetadataTool';
