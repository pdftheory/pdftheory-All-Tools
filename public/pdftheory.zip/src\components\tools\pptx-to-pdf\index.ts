export { PPTXToPDFTool } from './PPTXToPDFTool';
export { default } from './PPTXToPDFTool';
