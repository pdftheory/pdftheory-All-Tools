export { PageDimensionsTool, type PageDimensionsToolProps } from './PageDimensionsTool';
export { default } from './PageDimensionsTool';
