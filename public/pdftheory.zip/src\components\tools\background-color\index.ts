export { BackgroundColorTool, type BackgroundColorToolProps } from './BackgroundColorTool';
