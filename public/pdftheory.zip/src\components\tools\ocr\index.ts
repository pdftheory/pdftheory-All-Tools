export { OCRPDFTool, type OCRPDFToolProps } from './OCRPDFTool';
export { default } from './OCRPDFTool';
