/**
 * Rotate PDF Tool exports
 * Requirements: 5.1
 */

export { RotatePDFTool } from './RotatePDFTool';
export type { RotatePDFToolProps } from './RotatePDFTool';
