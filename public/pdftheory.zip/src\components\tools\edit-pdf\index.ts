export { EditPDFTool, type EditPDFToolProps } from './EditPDFTool';
