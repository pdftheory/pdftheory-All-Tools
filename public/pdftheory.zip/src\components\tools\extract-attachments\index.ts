export { ExtractAttachmentsTool, type ExtractAttachmentsToolProps } from './ExtractAttachmentsTool';
export { default } from './ExtractAttachmentsTool';
