/**
 * Merge PDF Tool Components
 * Requirements: 5.1, 5.2
 */

export { MergePDFTool, type MergePDFToolProps } from './MergePDFTool';
