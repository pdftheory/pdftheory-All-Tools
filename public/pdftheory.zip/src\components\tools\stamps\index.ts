export { StampsTool, type StampsToolProps } from './StampsTool';
