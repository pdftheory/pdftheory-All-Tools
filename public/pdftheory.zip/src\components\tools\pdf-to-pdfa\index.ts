export { PDFToPDFATool, type PDFToPDFAToolProps } from './PDFToPDFATool';
export { default } from './PDFToPDFATool';
