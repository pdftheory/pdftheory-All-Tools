export { SanitizePDFTool, type SanitizePDFToolProps } from './SanitizePDFTool';
export { default } from './SanitizePDFTool';
