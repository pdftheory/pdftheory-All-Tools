export { BookmarkTool, type BookmarkToolProps } from './BookmarkTool';
