export { HeaderFooterTool, type HeaderFooterToolProps } from './HeaderFooterTool';
