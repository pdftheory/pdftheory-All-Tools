/**
 * Alternate Merge Tool Component
 * Requirements: 5.1
 */

export { AlternateMergeTool, type AlternateMergeToolProps } from './AlternateMergeTool';
export { default } from './AlternateMergeTool';
