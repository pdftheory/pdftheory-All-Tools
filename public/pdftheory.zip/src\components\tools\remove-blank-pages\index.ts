export { RemoveBlankPagesTool, type RemoveBlankPagesToolProps } from './RemoveBlankPagesTool';
