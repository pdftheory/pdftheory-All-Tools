/**
 * Delete Pages Tool exports
 * Requirements: 5.1
 */

export { DeletePagesTool } from './DeletePagesTool';
export type { DeletePagesToolProps } from './DeletePagesTool';
