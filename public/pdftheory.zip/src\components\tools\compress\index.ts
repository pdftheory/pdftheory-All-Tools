export { CompressPDFTool, type CompressPDFToolProps } from './CompressPDFTool';
