export { XPSToPDFTool } from './XPSToPDFTool';
export { default } from './XPSToPDFTool';
