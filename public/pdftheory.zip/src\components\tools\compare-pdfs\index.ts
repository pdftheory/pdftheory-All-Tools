export { ComparePDFsTool, type ComparePDFsToolProps } from './ComparePDFsTool';
export { ComparePDFsTool as default } from './ComparePDFsTool';
