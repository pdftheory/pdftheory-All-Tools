export { EncryptPDFTool, type EncryptPDFToolProps } from './EncryptPDFTool';
export { default } from './EncryptPDFTool';
