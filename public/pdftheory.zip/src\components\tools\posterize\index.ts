export { PosterizePDFTool } from './PosterizePDFTool';
export type { PosterizePDFToolProps } from './PosterizePDFTool';
