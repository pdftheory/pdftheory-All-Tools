export { WatermarkTool, type WatermarkToolProps } from './WatermarkTool';
