export { RemoveMetadataTool, type RemoveMetadataToolProps } from './RemoveMetadataTool';
export { default } from './RemoveMetadataTool';
