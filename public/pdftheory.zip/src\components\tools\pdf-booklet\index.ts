export { PDFBookletTool, type PDFBookletToolProps } from './PDFBookletTool';
export { default } from './PDFBookletTool';
