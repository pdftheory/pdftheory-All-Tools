export { TableOfContentsTool, type TableOfContentsToolProps } from './TableOfContentsTool';
